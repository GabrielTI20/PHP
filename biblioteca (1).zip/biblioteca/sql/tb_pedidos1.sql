create table tb_pedidos(
    id INT PRIMARY KEY AUTO_INCREMENT,
    id_nome INT(20),
    id_livro INT(20)
);