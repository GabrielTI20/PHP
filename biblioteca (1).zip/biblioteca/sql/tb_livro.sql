create table tb_livro(
    id INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(200),
    genero VARCHAR(50),
    quantidade VARCHAR(20),
    valor FLOAT(4,2),
    publicacao YEAR
);