create table tb_cliente(
    id INT PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(200),
    idade INT(5),
    cpf VARCHAR(20),
    telefone VARCHAR(20),
    cep VARCHAR(20),
    endereco VARCHAR(200)
);