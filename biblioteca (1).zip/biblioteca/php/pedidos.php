


echo '<h2>vinculação dos bancos</h2>';


<?php
 echo'<h2>vinculação dos bancos';
 function consultPedidos(){
 
    $conexao = new PDO("mysql:host=localhost;dbname=biblioteca","root","");
 
  $select = "SELECT * FROM tb_pedidos";
 
  $resultado = $conexao->query($select);
 
  $consulta = $resultado->fetchAll();
 
  $sql = "SELECT * FROM tb_perdidos
  INNER JOIN tb_cliente ON tb_perdidos.`id_cliente` = tb_cliente.id";


  $sql2 = "SELECT * FROM tb_perdidos
  INNER JOIN tb_livro ON tb_perdidos.`id_livro` = tb_livro.id";
 
    echo '<ul>';
    foreach ($consulta as $linha) {
        echo '<hr><pre>';
        echo '<p>'. 'id: ' . $linha['id'] . '</p>';
        echo '<p>'. 'id_cliente: ' . $linha['id_cliente'] . '</p>';
        echo '<p>'. 'id_livro: ' . $linha['id_livro'] . '</p>';
        echo '<hr>';
    }
    echo '</ul>';
}
consultPedidos();
 
function InserirPedidos($id_cliente, $id_livro)
{
  $conexao = new PDO("mysql:host=localhost;dbname=biblioteca","root","");
 
  $guarda = "INSERT INTO tb_pedidos (id_cliente, id_livro) VALUES (:id_cliente, :id_livro)";
 
  $preparacao = $conexao->prepare($guarda);
 
  $preparacao->bindParam(":id_cliente", $id_cliente);
  $preparacao->bindParam(":id_livro", $id_livro);
  $preparacao->execute();
}
 
InserirPedidos("2", "3", "3");
   

?>