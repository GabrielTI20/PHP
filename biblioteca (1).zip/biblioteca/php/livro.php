<?php

echo'<h2>livros php</h2>';
function consultPedidos(){
 
    $conexao = new PDO("mysql:host=localhost;dbname=biblioteca","root","");
   
    $select = "SELECT * FROM tb_livro";
   
    $resultado = $conexao->query($select);
   
    $consulta = $resultado->fetchAll();
   
      $sql = "SELECT * FROM tb_pedido
      INNER JOIN tb_livro ON tb_pedido.`id_cliente` = tb_livro.id";
   
      $sql2 = "SELECT * FROM tb_pedido
      INNER JOIN tb_livro ON tb_pedido.`id_livro` = tb_livro.id";
   
      echo '<ul>';
      foreach ($consulta as $linha) {
          echo '<hr><pre>';
          echo '<p>'. 'ID: ' . $linha['ID'] . '</p>';
          echo '<p>'. 'id_cliente: ' . $linha['id_cliente'] . '</p>';
          echo '<p>'. 'id_livro: ' . $linha['id_livro'] . '</p>';
          echo '<hr>';
      }
      echo '</ul>';
  }
  consultPedidos();

function cadastroLivro($nome,$genero,$quantidade,$valor,$publicacao) 
{

    $conexao = new PDO("mysql:host=localhost;dbname=biblioteca","root","");

    $cadastroLivro = "INSERT INTO tb_livro (nome, genero, quantidade, valor, publicacao) VALUES (:nome, :genero, :quantidade, :valor, :publicacao)";

    $livro = $conexao->prepare($cadastroLivro);
    $livro->bindParam(':nome', $nome);
    $livro->bindParam(':genero', $genero);
    $livro->bindParam(':quantidade', $quantidade);
    $livro->bindParam(':valor', $valor);
    $livro->bindParam(':publicacao',$publicacao);
    $livro->execute();
}

cadastroLivro($_POST('nome'),$_POST('idade'),$_POST('cpf') ,$_POST('telefone') ,$_POST('cep'),$_POST('endereco'));

echo $_POST('nome');
echo $_POST('idade');
echo $_POST('cpf');
echo $_POST('telefone');
echo $_POST('cep');
echo $_POST('endereco');


?>