<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <?php
    //define um array nomes
    $nomes = array("João", "Maria", "Pedro", "Ana");

    //Exibe os nomes  em uma lista HTML
    
    unset($nomes[3]); // remove um nome guardado na 


    echo "<h2>Lista de nomes</h2>";
    
    foreach ($nomes as $nome) {
        echo "<li>$nome</li>";
    }
    
    
    echo "<h2>Nova Lista</h2>";
    
    $nomes1= array("Julia","Nathy","Roberto");
    foreach ($nomes1 as $nome2) {
        echo "<li>$nome2</li>";
        
    }


    echo "<h2>adiciona na Lista</h2>";

    $nomes3 = array("Camila", "carlos");

    array_push($nomes3, "Alice", "Jorge");
    print_r($nomes3);


    echo "<h2>Lista ordem alfabética</h2>";

    
    $nomes4= array("Julia","Nathy","Roberto","Ana", "Bia");

    sort($nomes4);
    foreach ($nomes4 as $nome3) {
        echo "<li>$nome3</li>";
        
    }
    ?>


</body>

</html>