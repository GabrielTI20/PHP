<!DOCTYPE html>
<html>
<head>
<title>cálculo de Idade</title>
<meta charset="UTF-8">
</head>
<body>
<hi>cálculo de Idade</h1>


<?php
// vou fazer o outro arquivo só que com POST

$nome = $_REQUEST["nome"];
$nasc = $_REQUEST["nasc"];
$atual = date("Y");
$idade = $atual - $nasc;
echo $nome ." a sua idade é ". $idade . " anos.";

?>
<p><input type="button" value="voltar" onclick="javascript:history.back();"></p>

</body>
</html>