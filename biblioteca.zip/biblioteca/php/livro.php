<?php

echo'<h2>livros php</h2>';

function cadastroLivro($nome,$genero,$quantidade,$valor,$publicacao) {

    $conexao = new PDO("mysql:host=localhost;dbname=biblioteca","root","");

    $cadastroLivro = INSERT INTO tb_cliente (nome, genero, quantidade, valor, puplicacao) VALUES (:nome, :genero, :quantidade, :valor, :puplicacao);

    $livro= $conexao->prepare($cadastroLivro);
    $livro->bindParam(':nome', $nome);
    $livro->bindParam(':genero', $genero);
    $livro->bindParam(':quantidade', $quantidade);
    $livro->bindParam(':valor', $valor);
    $livro->bindParam(':puplicacao',$publicacao);
}
;
cadastroLivro();
?>