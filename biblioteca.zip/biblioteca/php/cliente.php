<?php
echo'<h2>livros php</h2>';

function cadastroCliente($nome, $idade, $cpf, $telefone, $cep , $endereco){

    $conexao = new PDO("mysql:host=localhost;dbname=biblioteca","root","");

    $cadastroCliente = INSERT INTO tb_cliente (nome, idade, cpf, telefone, cep , endereco) VALUES (:nome , :idade , :cpf , :telefone , :cep , :endereco);
    $livro= $conexao->prepare($cadastroClinte);
    $livro->bindParam(':nome', $nome);
    $livro->bindParam(':idade', $idade);
    $livro->bindParam(':cpf', $cpf);
    $livro->bindParam(':telefone', $telefone);
    $livro->bindParam(':cep',$cep);
    $livro->bindParam(':endereco',$endereco);

}
;
cadastroCliente();
?>